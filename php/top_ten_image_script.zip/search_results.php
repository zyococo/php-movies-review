<?php
/*
        search_results - web page with search results

        RAD - 
        Team Name: ICA Designs
        Team Members:
            Ivan Ng
            Caspian Maclean
            Andrew Williamson
        Date: 05/11/2021
        Sprint: One
        Task: Make all the pages responsive.
*/
?>
<!-- <!DOCTYPE html>
<html> -->
    <!-- <head>
        <link rel="stylesheet" href="style.css">
        <title>
            Search results
        </title>
    </head>
    <body>
       
        <header>
            
        </header> -->
        <div class="container-fluid text-center mt-3" id="results">
            <h1>Search results</h1>
        </div>
        <div class="row justify-content-center g-0">
            <div class="col-12 col-sm-12 col-md-10 col-xl-6">
                <?php require "search_results_script.php";?>
            </div>
        </div>  
    <!-- </body> -->
<!-- </html> -->
