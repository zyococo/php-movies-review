(function () {
    'use strict'
  
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')
  
    var valid = true;
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
    .forEach(
        function (form) {
            form.addEventListener(
                'submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault()
                        event.stopPropagation()
                        valid = false;
                    } else {
                        event.preventDefault()
                        $.ajax(
                            {
                                type: "post",
                                url: "register_script.php",
                                data: $('#registerForm').serialize(),
                                success: function (data) {
                                    console.log(data);
                                    $('#staticBackdrop').modal('toggle');
                    
                                }
                            }
                        )
                    }
                    form.classList.add('was-validated')
                }, false
            )
        }
    )
})()